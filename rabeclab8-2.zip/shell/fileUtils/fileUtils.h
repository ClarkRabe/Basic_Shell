#ifndef FILEUTILS_FILEUTILS_H_
#define FILEUTILS_FILEUTILS_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int isFile(char* fin);

#endif
