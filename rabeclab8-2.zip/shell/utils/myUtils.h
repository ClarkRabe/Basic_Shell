
#ifndef MYUTILS_H
#define MYUTILS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX 100



int menu();

void strip(char *array);

char* parse(char* toParse, char* delim);
#endif
