
#ifndef REDIRECT_REDIRECT_H_
#define REDIRECT_REDIRECT_H_

int containsRedirect(char* s);

#endif
